using Domain.ValueObject.MechanicTask;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Infrastructure.Configuration.MechanicTask;

public sealed class MechanicTaskConfiguration : IEntityTypeConfiguration<Domain.Entities.MechanicTask.MechanicTask>
{
    public void Configure(EntityTypeBuilder<Domain.Entities.MechanicTask.MechanicTask> builder)
    {
        builder.ToTable("tarea_mecanico");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
            .HasColumnName("id")
            .ValueGeneratedOnAdd();

        builder.Property(x => x.OrderId)
            .HasConversion(
                x => x.Value,
                x => MechanicTaskOrderId.Create(x))
            .HasColumnName("orden_id")
            .IsRequired();

        builder.Property(x => x.MechanicId)
            .HasConversion(
                x => x.Value,
                x => MechanicTaskMechanicId.Create(x))
            .HasColumnName("mecanico_id")
            .IsRequired();

        // ↓ ESTOS SON LOS TRES CONVERSORES CORREGIDOS ↓

        var serviceTypeConverter = new ValueConverter<MechanicTaskServiceTypeId?, Guid?>(
            v => v == null ? (Guid?)null : v.Value,
            v => v == null ? null : (MechanicTaskServiceTypeId?)MechanicTaskServiceTypeId.Create(v.Value));

        builder.Property(x => x.ServiceTypeId)
            .HasConversion(serviceTypeConverter)
            .HasColumnName("tipo_servicio_id");

        var fechaInicioConverter = new ValueConverter<MechanicTaskFechaInicio?, DateTime?>(
            v => v == null ? (DateTime?)null : v.Value,
            v => v == null ? null : (MechanicTaskFechaInicio?)MechanicTaskFechaInicio.Create(v.Value));

        builder.Property(x => x.FechaInicio)
            .HasConversion(fechaInicioConverter)
            .HasColumnName("fecha_inicio");

        var fechaFinConverter = new ValueConverter<MechanicTaskFechaFin?, DateTime?>(
            v => v == null ? (DateTime?)null : v.Value,
            v => v == null ? null : (MechanicTaskFechaFin?)MechanicTaskFechaFin.Create(v.Value));

        builder.Property(x => x.FechaFin)
            .HasConversion(fechaFinConverter)
            .HasColumnName("fecha_fin");

        // ↑ FIN DE LOS CONVERSORES CORREGIDOS ↑

        builder.Property(x => x.Description)
            .HasConversion(
                x => x.Value,
                x => MechanicTaskDescription.Create(x))
            .HasColumnName("descripcion")
            .HasColumnType("text")
            .IsRequired();

        builder.Property(x => x.HoursWorked)
            .HasConversion(
                x => x.Value,
                x => MechanicTaskHoursWorked.Create(x))
            .HasColumnName("horas_trabajadas")
            .HasColumnType("decimal(5,2)")
            .IsRequired();

        builder.Property(x => x.HourlyCost)
            .HasConversion(
                x => x.Value,
                x => MechanicTaskHourlyCost.Create(x))
            .HasColumnName("costo_hora")
            .HasColumnType("decimal(10,2)")
            .IsRequired();

        builder.Property(x => x.Status)
            .HasConversion(
                x => x.Value,
                x => MechanicTaskStatus.Create(x))
            .HasColumnName("estado")
            .HasMaxLength(20)
            .IsRequired();

        builder.HasIndex(x => x.OrderId).HasDatabaseName("idx_tarea_orden");
        builder.HasIndex(x => x.MechanicId).HasDatabaseName("idx_tarea_mecanico");

        builder.HasOne<Domain.Entities.OrderService.OrderService>()
            .WithMany()
            .HasForeignKey(x => x.OrderId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasOne<Domain.Entities.Users.User>()
            .WithMany()
            .HasForeignKey(x => x.MechanicId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne<Domain.Entities.ServiceType.ServiceType>()
            .WithMany()
            .HasForeignKey(x => x.ServiceTypeId)
            .IsRequired(false)
            .OnDelete(DeleteBehavior.Restrict);
    }
}