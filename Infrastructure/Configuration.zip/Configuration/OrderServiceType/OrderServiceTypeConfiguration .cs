using Domain.ValueObject.OrderServiceType;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configuration.OrderServiceType;

public sealed class OrderServiceTypeConfiguration : IEntityTypeConfiguration<Domain.Entities.OrderServiceType.OrderServiceType>
{
    public void Configure(EntityTypeBuilder<Domain.Entities.OrderServiceType.OrderServiceType> builder)
    {
        builder.ToTable("orden_tipo_servicio");

        // PK compuesta igual que en el SQL — ignorar Id heredado
        builder.Ignore(x => x.Id);

        builder.HasKey(x => new { x.OrderId, x.ServiceTypeId });

        builder.Property(x => x.OrderId)
            .HasConversion(
                x => x.Value,
                x => OrderServiceTypeOrderId.Create(x))
            .HasColumnName("orden_id")
            .IsRequired();

        builder.Property(x => x.ServiceTypeId)
            .HasConversion(
                x => x.Value,
                x => OrderServiceTypeServiceTypeId.Create(x))
            .HasColumnName("tipo_servicio_id")
            .IsRequired();

        // FK → orden_servicio (ON DELETE CASCADE)
        builder.HasOne<Domain.Entities.OrderService.OrderService>()
            .WithMany()
            .HasForeignKey(x => x.OrderId)
            .OnDelete(DeleteBehavior.Cascade);

        // FK → tipo_servicio
        builder.HasOne<Domain.Entities.ServiceType.ServiceType>()
            .WithMany()
            .HasForeignKey(x => x.ServiceTypeId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}